import React from 'react';
import { View, Text, Button } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { deleteTodo } from '../redux/todoSlice';

export default function DeleteTodoScreen({ route, navigation }) {
  const { id } = route.params;
  const todo = useSelector(state => state.todos.find(t => t.id === id));
  const dispatch = useDispatch();

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 18, marginBottom: 20 }}>Bạn có chắc muốn xóa công việc này?</Text>
      <Text style={{ marginBottom: 20, color: 'red' }}>{todo?.text}</Text>
      <Button title="Xóa" color="red" onPress={() => { dispatch(deleteTodo(id)); navigation.navigate('TodoList'); }} />
    </View>
  );
}
